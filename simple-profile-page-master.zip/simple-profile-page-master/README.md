# Simple Profile Page Example

Contoh pembuatan profile page untuk miniclass web

![Screenshot](assets/image/screenshot.png)

